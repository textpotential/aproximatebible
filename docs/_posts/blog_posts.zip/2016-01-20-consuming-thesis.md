---
layout:	post
title:	consuming thesis
date:	2016-01-20 19:55:23
image:	/assets/article_images/e5c54775-829c-48f9-9b3a-8e296e76b0d4.png
---
It is no secret that the idea of thesis makes me uncomfortable. Recently, I have been asked to offer a clearer articulation (thesis) of what I am trying to say about the relationship between Emmanuel Levinas’s philosophy of the face and technologies of reading and writing. After reading back over the conversations of *a proximate bible*, particularly the hints toward these ideas in [proliferation of faces]({{site.baseurl}}{% raw %}{% post_url 2015-03-21-proliferation-of-faces %}{% endraw %}), below are the telescoping theses I came up with. Each of these statements can be taken on their own or together.

-   Medium matters.

-   The face to face describes a material encounter. This inter*face* is not limited to the material medium of human perception.

-   Inter*faces* (technologies) shape meaning as much as the ‘texts’ they perform. The face to face in Levinas begs for a humanness that resists consumption, a contact without grasp (proximity). Reading and writing interfaces built on emerging internet media technologies can encourage dispositions toward non-commodified human encounter, i.e. the face to face.

-   Rabbinic readings of bible as book first signaled for Levinas a meaning making beyond cognitive categorization (consumption). As the cultural dominance of print wanes, material media translations of bible (and book) from bound print codex to dynamic aggregation of digital fragments can provide spaces to practice the ongoing entanglement of strategies and tactics that constitute the cultural phenomenon of bible as a human interface.

I ended up spending a lot of time considering this question of thesis and trying to concisely distill, condense, crystalize, dare I say commodify, what I am trying to say in this dissertation. Whatever I come up with here is partial and flawed and, at its best, open and curious. So, I keep wondering, what work is this process of ‘thesis distilling’ doing for me or for my readers? Is this process useful for me as a writer or is it more of a courteous consideration for the reader, so that the aim (payoff?) of a work is always in view? Does thesis offer a particular genre or guild specific strategy of discourse that can offer an interface for engagement or evaluation? Is a singular and clearly articulated thesis the defining mark of the dissertation genre, a decidedly print governed genre? If so, is there a way to translate the work that thesis-izing does into a less print dominated medium?

> My initial title for this post was ‘thesis-izing’. It turns out this word ‘thesisize’ has an entry in the [urban dictionary](http://www.urbandictionary.com/define.php?term=Thesisize) and has a hashtag presence on twitter ([\#thesisizing](https://twitter.com/hashtag/thesisizing)). Different than the process of distilling and consolidating I am struggling with here, thesis-ize is more often used to indicate the arduous task of composing the large academic work typically governed by this singular and clearly articulated thesis. It is suggestive that this distilled nugget of a thesis, the most consumable interface of a work, has become a synecdoche for the entire creative process that marks the largest project of many students’ academic careers.

If I had to articulate a thesis for this particular post on thesis, it would be what was just suggested in the note above, that *a thesis is the most consumable or commodified interface of a creative work*. Given that *a proximate bible* is exploring reading/writing interfaces that resist the dominance of commodification, can we translate the values of thesis into a medium that is more fragmentary, dynamic, and aggregative? Or not? Let’s imagine thesis undergoing something like the Lyotardian move from university to institute, from metanarrative to *petit récit* or ‘little narrative’ (Lyotard, [*The Postmodern Condition*](http://amzn.com/0816611734), 60)?

![]({{site.baseurl}}/assets/article_images/e5c54775-829c-48f9-9b3a-8e296e76b0d4.png)

In the space of *a proximate bible*, a single overarching narrative (thesis) does not govern the conversation. Instead, theses of the ‘little narrative’ variety **emerge** through use, the ongoing and palimpsestuous struggle of curation and interaction. If we take this Lyotardian notion of little narrative alongside the literary montage methodology of Walter Benjamin’s [*Arcades Project*](http://amzn.com/0674008022),

![]({{site.baseurl}}/assets/article_images/f5188650-0edf-49fe-811c-12ab8198cd16.png)

we can begin to imagine an *an-archic* performance of thesis (see [anarchic approximations]({{site.baseurl}}{% raw %}{% post_url 2015-01-11-anarchic-approximations %}{% endraw %}) for specifics on my use of the term ‘anarchic’). Instead of an originary idea reigning over a work, that then comes to represent the work in its totality, theses can arise in the interfaces that shape the space of a work as it is used. I make claims all over these spaces, as do others, so in one sense, theses abound (or are they unbound?). Yet, this online medium, built from a constellation of interfaces, attempts to practice a translation of thesis from the consumable *arche* of metanarrative to the poeitic fragments of everyday practice.

> In his reflections on Lyotard’s later writings, Stephen Barker suggests an explicit connection between fragment and *petit récit* in Lyotard (Barker, [“The Weight of Writing: Lyotard’s Anti-Aesthetic in ‘À l’écrit bâté’”](https://books.google.com/books?id=qEaNwpOsonwC&pg=PT90&dq=lyotard+petit+recit+fragment&source=gbs_toc_r&cad=3#v=onepage&q=lyotard petit recit fragment&f=false)).

![]({{site.baseurl}}/assets/article_images/1e8ca823-dd37-4b4f-9ee9-86df029646a9.png)
