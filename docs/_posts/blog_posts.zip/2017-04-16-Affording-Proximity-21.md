---
layout:	post
title:	Affording Proximity 2.1
date:	2017-04-16 03:57:13

---
For a history of changes incorporated here, see [Chapter 2 History](https://github.com/textpotential/bibliarchic/commits/master/chapt2b.md)
on GitHub.

Now that we have established interface and user as useful ways to talk about books and reading in our emerging technological landscape, I will move on to explore the value of one particular affordance in interface based on the philosophy of Emmanuel Levinas and particularly his notion of proximity. Pushing proximity beyond its typical connotation of simple physical closeness, I will argue for interfaces that afford both nearness as response-ability and distance as resistance to mastery. This expansion and entanglement of nearness and distance in proximity can help us imagine bible as interface amidst the familiar anxiety of changing notions of nearness and distance as new technologies emerge.

Throughout the history of technological change, one of the consistent questions that arises is how to deal with the expanding affordance of nearness offered by new technologies. Nearness in the context of interface typically suggests a spatial or relational contiguity that facilitates easier access to resources or easier exchange of information. Transportation technologies like horses, automobiles, and airplanes effectively increased nearness by decreasing the energy and time required to travel across large distances. Communication technologies such as the telephone, email, and mobile devices have expanded nearness by increasing our ability to communicate across vast distances in short time spans with increasing amounts and types of data. In the realm of bible interfaces, the Codex Sinaiticus Project web interface has brought me as a user much nearer to this 4th century manuscript. First of all, this project brings together fragments of the manuscript into one space of encounter from four different libraries around the world. Instead of traveling to the British Library, the Library of the University of Leipzig, the National Library of Russia in Saint Petersburg, and the Holy Monastery of the God-Trodden Mount Sinai to encounter all of the extant portions of this important codex, I can browse them all from a single web interface on my computer no matter where I am in the world. This aggregation of artifacts into one interface is one form of nearness afforded by digitization of manuscripts and internet technologies.

In addition to the collecting of fragments, the Codex Sinaiticus Project website provides high resolution digital images with easy zoom capabilities, transcriptions, english translations, and physical descriptions of each leaf of each quire that is extant. Due to the lighting techniques used to capture the digital images of the manuscript and the zoom capabilities, this interface of the manuscript can offer a user a closer or nearer look at some of the details of the material manuscript that would even be possible handling the manuscript sitting in the reading room of the British Library. Without a doubt, this web interface of Codex Sinaiticus increases nearness by allowing many more people to engage this historic book with ease and by highlighting details of the manuscript that may escape a user participating in other interfaces of the manuscript. In light of the immense benefits provided by this nearness to Codex Sinaiticus, it is also without question a *different* encounter with the manuscript than turning the fragile pages with sterile gloves in a climate controlled reading room at the University of Leipzig. As my colleague Danny Yencich reminded me in a discussion of the digital materiality of the Codex Sinaiticus project, this web interface does not provide a user is an encounter with the spine, covers and binding of this book. Yencich rightfully asks, “Are such paratexts really so unimportant for the study of this book?”<a href="#fn1" id="fnref1" class="footnoteRef"><sup>1</sup></a> There are undoubtedly other significant changes in the way we study and imagine this fantastic book in this alternative material interface. What do we lose not experiencing the sound and smell of the page turns or in foregoing the process of turning pages at all? Does the granular access to one leaf at a time shape a different conception of the whole codex and the relationship between the fragments?

## Growing Anxieties

Similar questions and concerns about the growing affordance of nearness are prevalent in the contemporary debates about the impact of internet, social media, and mobile technologies on human cognition and human relationship. Sherry Turkle has become a prominent public voice in discussions of technology and its social effect, as evidenced in the impressive attention captured by her new book, *Reclaiming Conversation: The Power of Talk in a Digital Age*.<a href="#fn2" id="fnref2" class="footnoteRef"><sup>2</sup></a> I first encountered Turkle’s work while engaging a Richard Cohen article, “Ethics and Cybernetics: Levinasian Reflections,” (Cohen 2000) in my struggle with face to face language in online education.<a href="#fn3" id="fnref3" class="footnoteRef"><sup>3</sup></a> Using her work from 1995, *Life on the Screen*,<a href="#fn4" id="fnref4" class="footnoteRef"><sup>4</sup></a> Cohen offers Turkle as an example of media scholars who champion the advantages of cybernetics and internet communication technologies for redefining subjectivities in the direction of post-modern notions of multiplicity and instability.<a href="#fn5" id="fnref5" class="footnoteRef"><sup>5</sup></a>

Turkle’s more recent work has shifted focus from this earlier celebration of the fragmented self to a serious anxiety about the effects of robotics and mobile devices on our social capacities as humans (Turkle 2011; Turkle 2015).<a href="#fn6" id="fnref6" class="footnoteRef"><sup>6</sup></a> Two minutes into a 2015 NPR interview titled ‘Making the Case For Face to Face in an Era of Digital Conversation,’<a href="#fn7" id="fnref7" class="footnoteRef"><sup>7</sup></a> Turkle suggests that “face to face conversation is the most human and humanizing thing that we do, it’s where we learn to put ourselves in the place of the other.” For many, this phrase, “face to face,” as Turkle uses it has come to represent “real” human interaction as opposed to a weak simulation or even cheap imitation that happens through internet media. In a sense, we could describe Turkle’s concerns as the growing tendency people have to choose one kind of nearness, a thin nearness, over a more “real” and valuable nearness of the so called “face to face.” Stated another way, Turkle warns us of the detrimental effects (greater distance) on personal relationship and intimacy brought about by the ever expanding nearness to information and connection provided by mobile devices and internet technologies. Her provocative suggestion of the negative impact of a mobile phone on the table during an interview is a perfect illustration of this interplay of nearness and distance. The nearness afforded by the mobile phone introduces some distance between the two people sitting in the radio studio together, and this exchange is a net loss in Turkle’s estimation.

Turning more specifically to books and users, Nicholas Carr has been a consistent voice of concern over the increasing nearness of internet reading interfaces. In his more current work, *The Glass Cage* and *Utopia is Creepy*, Carr continues to provide a useful voice challenging assumptions that the growing ubiquity of internet and computer technologies have a positive impact on human lives.<a href="#fn8" id="fnref8" class="footnoteRef"><sup>8</sup></a> The book that put Carr on the map, though, was a book specifically about reading and the internet titled *The Shallows: What the Internet is Doing to Our Brains*.<a href="#fn9" id="fnref9" class="footnoteRef"><sup>9</sup></a> In this book, Carr’s argument is basically that the distractive hyperlinking affordances of internet reading interfaces is rewiring the human brain to think more shallowly. Carr’s attention to the neuroplasticity of the human brain even in adults and the impact of interface use on the shaping of brain pathways provides an excellent example of the material entanglement that operates in interface. Human brains designed internet reading platforms and these interfaces are now participating in the design of the human brain. Yet, rather than simply pointing to the differences emerging in neural pathways that seem connected to reading on the internet, Carr laments the waning of the codex interface and identifies these new dispositions and brain wirings as “shallow.”<a href="#fn10" id="fnref10" class="footnoteRef"><sup>10</sup></a>

Carr actually begins his entire analysis with a look back to McLuhan’s most famous book, *Understanding Media*, and his most well know aphorism, “the medium is the message.”<a href="#fn11" id="fnref11" class="footnoteRef"><sup>11</sup></a> Although he clearly respects the prescience and value of McLuhan’s work, even using McLuhan’s own language as the subtitle for his prologue, Carr immediately betrays an underlying fear of change and nostalgic anxiety as he emphasizes McLuhan’s polemic against the neutralists without any attention given to McLuhan’s celebration of art and social reorganization in the retribalization made possible by the collapse of time and space brought on by electric technology.<a href="#fn12" id="fnref12" class="footnoteRef"><sup>12</sup></a> While Carr gives no attention to this part of McLuhan’s discussion of electric technology, I can’t help but hear echoes of McLuhan’s global village when I read Clay Shirky’s assessment of the internet age in *Cognitive Surplus*, which offers a stark and compelling counterpoint to Carr’s pessimism.<a href="#fn13" id="fnref13" class="footnoteRef"><sup>13</sup></a> Carr leverages McLuhan’s clever and incisive claims about the power of technology in shaping human culture, but all the while operates with a sense that the dangers of digital technology are inevitably fatal. Though McLuhan is exceedingly clear on the risks of technological change and advancement, the tone of *Understanding Media* strikes me as loaded with potential and possibility, whereas even Carr’s title spells doom.

The anxiety that drives Carr’s argument in *The Shallows* stems from a loss of the distance provided by the print codex interface. Internet technologies afford increasing nearness with an always expanding set of possible things to engage, such that users can no longer focus in a sustained manner on a singular, linear text. On the contrary, a codex affords a more singular nearness in interface, with covers to mark what is in and what is out typically with some measure of linear progression from beginning to end. In Carr’s imagination, the codex provides a focused and contained nearness that creates a distance from all other things, which in turns facilitates a deep thinking that is more valuable than the shallowness afforded by the internet. Long durations of time and the concept of depth are also forms of distance and Carr finds these affordances of distance in the codex interface. For Carr, the growing ubiquity of internet reading interfaces afford a nearness of multiple foci, shorter durations, and lack of depth that have a decidedly negative impact on human learning and knowledge.<a href="#fn14" id="fnref14" class="footnoteRef"><sup>14</sup></a>

## Nothing New

In his long historical run up to the current media situation of the internet, Carr reminds readers that the anxiety around changes in technology and its impact on the human brain are not at all new. In the 4th century before the common era, as the technology of an alphabet began to take root, writing emerged as a new technology for communication and learning. Following the lead of Walter Ong’s analysis of Plato is his work *Orality and Literacy*, Carr points to what seems to be a negative view of writing in *Phaedrus* and more positive views on literacy in *The Republic*.<a href="#fn15" id="fnref15" class="footnoteRef"><sup>15</sup></a> Ong and Carr reference the well trodden passage from *Phaedrus* that communicates a worry about the impact of writing on memory, since writing affords easy reference to a content set outside the memory of an individual.<a href="#fn16" id="fnref16" class="footnoteRef"><sup>16</sup></a> Undoubtedly, these reflections on an entirely different time period of major technological transition provide a helpful reminder that these anxieties about emerging technologies are not a new phenomenon. Further reflections on this anxious passage from *Phaedrus* in conversation with other mentions of writing in the Platonic corpus point less to a concern about the difference between internal and external memory technologies and more toward a worry about the impact of writing on dynamic dialog. Lane Wilkinson’s analysis of the views on writing in *Phaedrus*<a href="#fn17" id="fnref17" class="footnoteRef"><sup>17</sup></a> points toward a passage shortly following the anxious bit about memory, where Socrates says to Phaedrus,

> I cannot help feeling, Phaedrus, that writing is unfortunately like painting; for the creations of the painter have the attitude of life, and yet if you ask them a question they preserve a solemn silence. And the same may be said of speeches. You would imagine that they had intelligence, but if you want to know anything and put a question to one of them, the speaker always gives one unvarying answer. And when they have been once written down they are tumbled about anywhere among those who may or may not understand them, and know not to whom they should reply, to whom not: and, if they are maltreated or abused, they have no parent to protect them; and they cannot protect or defend themselves.<a href="#fn18" id="fnref18" class="footnoteRef"><sup>18</sup></a>

One way to frame this concern is as an anxiety about the increasing nearness or availability of a written text to a user and the corresponding distancing of the speaker or author. If, as Wilkinson suggests, the primary value operative for Plato is dialog, then writing provided an interface in antiquity that afforded a new kind of nearness to words and ideas that threatened the participation in dialog. Susan Dobra points to a short passage in the “Seventh Letter” that highlights this again, where Plato says, “that is why no intelligent man will ever dare to commit his thoughts to words, still less to words that cannot be changed, as is the case with what is expressed in written characters.”<a href="#fn19" id="fnref19" class="footnoteRef"><sup>19</sup></a> As both Wilkinson and Dobra highlight so nicely, it is the fixicity of written text that affords an irresponsible nearness for the reader in exchange for the dynamics of dialog. This concern about the impact of increasing nearness provided by new technologies, particularly the effects it might have on the ambiguity and dynamics of dialog sound similar to Drucker’s questioning of the mechanistic determinism of contemporary interface theories operative in the software world. In a sense, both Plato and Drucker are advocating for a nearness of the subject over the nearness of content.

## Dealing with Distance

In a much nearer time period, Martin Heidegger delivered a set of lectures just after the second world war addressing the changes in nearness and distance brought about by the rise of mechanical technologies.<a href="#fn20" id="fnref20" class="footnoteRef"><sup>20</sup></a> These lectures, know as the Bremen lectures, occurred in Bremen in 1949 as Heidegger’s first public address after the war ended. He begins the lecture series with a clear statement of the issue he is confronting, saying, “All distances in time and space are shrinking.”<a href="#fn21" id="fnref21" class="footnoteRef"><sup>21</sup></a> The rest of the lecture series explores the changing relationship between distance and nearness with the rise of modern technologies such as airplanes, radio, film, and television.<a href="#fn22" id="fnref22" class="footnoteRef"><sup>22</sup></a> Heidegger frames his concern in terms of distance not nearness, because he will redefine nearness as something exceeding the spatial and relational closeness we have been exploring thus far. Distance, for Heidegger remains spatial or relational, while nearness comes to signify an intimate encounter related to truth, which experiences the “actuality” of a thing, and technology does not offer this even as it collapses the distance of space and time.<a href="#fn23" id="fnref23" class="footnoteRef"><sup>23</sup></a> In a subtle twist of the more well known title of the expanded version of lecture two, “The Question Concerning Technology,” the concern in these questions about technology is what happens to the possibility of nearness as difference when technologies afford a kind of distancelessness?<a href="#fn24" id="fnref24" class="footnoteRef"><sup>24</sup></a> Heidegger will go on to articulate the essence of technology as the process that renders all being, humans and nature included, as distanceless without nearness.<a href="#fn25" id="fnref25" class="footnoteRef"><sup>25</sup></a> He begins the second lecture saying, “All mastery of distances brings no nearness at all.”<a href="#fn26" id="fnref26" class="footnoteRef"><sup>26</sup></a> Though the language is a bit different, the distancelessness that has Heidegger bothered is a historically located version of the anxiety we saw about the affordance of nearness in Plato, Turkle, and Carr.

Also interested in the impact of these changes in scale of nearness and distance brought on by technologies, another thinker, Roger Silverstone, more recently has taken up this question about distance in relation to internet technologies and cyberspace. Advocating for what he calls “proper distance” as a framework for the possibility of ethics in internet communication technologies, Silverstone argues for the necessity to resist the tendency toward the distancelessness and overnearness possible in emerging technologies as highlighted by Heidegger’s anxieties we have just seen.<a href="#fn27" id="fnref27" class="footnoteRef"><sup>27</sup></a> Silverstone offers two important directives in our consideration of nearness and distance in interface. First, challenging the common exhuberance about the possibilities for connection and communication provided by the internet as a kind of nearness, Silverstone champions the value of distance as irreducible difference or even the insistent interruption of connection afforded by internet communication technologies.<a href="#fn28" id="fnref28" class="footnoteRef"><sup>28</sup></a> Second, Silverstone signals the usefulness of Emmanuel Levinas’s concept of proximity as a way to consider the difficult tension of contact and separation necessary to afford ethical human relationship in electronically mediated spaces.<a href="#fn29" id="fnref29" class="footnoteRef"><sup>29</sup></a> Taking Silverstone’s lead in his helpful corrective to the focus simply on nearness in emerging technologies, I too find Levinasian proximity a valuable framework for exploring even human-machine interface as a constant negotiation of nearness and distance in what can be imagined as contact without grasp.

## Proximity: Contact Without Grasp

This philosophical notion of subjectivity in Levinas, proximity, can operate explicitly as an affordance offered in interface beyond the human-human ethical encounter. Rather than asking whether emerging technologies are ethical or whether ethical human relationship is possible in our present technological landscape,<a href="#fn30" id="fnref30" class="footnoteRef"><sup>30</sup></a> I will use the operations of proximity in Levinasian philosophy as a model for exploring the nearness and distance afforded by bible in its many lives as interface. Levinas himself speaks and writes very little about technology explicitly,<a href="#fn31" id="fnref31" class="footnoteRef"><sup>31</sup></a> but his negotiations of nearness and distance in human relationship through his idea of proximity have a great deal to offer our discussions of interface.

Proximity as a different approach to human relationship than ontology or being blossoms in the last of Levinas’s large phiosophical works, *Otherwise Than Being* (*OTB*).<a href="#fn32" id="fnref32" class="footnoteRef"><sup>32</sup></a> Proximity emerges in *OTB* as an approach that increases the nearness of responsibility and at the same time increases the distance from mastery. Immediately, we can see here that proximity is not a synonym for nearness and that nearness is no longer simply the opposite of distance. Proximity becomes a problematization of the distance/nearness spatial binary, where both nearness and distance are redefined and enhanced in a process of “approach” that demands responsibility and resists mastery. Levinas writes, “for proximity is not a simply asymptotic approach of its ‘term.’ Its term is not an end. The more I answer the more I am responsible; the more I approach the neighbor with which I am encharged the further away I am.”<a href="#fn33" id="fnref33" class="footnoteRef"><sup>33</sup></a>

In this resistance to the asymptote as a metaphor for proximity, Levinas indicates concepts of nearness and distance that are not derived simply from spatial contiguity or its lack. First and foremost, proximity is near as sociality, a “relationship with,” not simply a physical closeness in space and time.<a href="#fn34" id="fnref34" class="footnoteRef"><sup>34</sup></a> This “relationship with” is the core of interface as we have defined it in chapter one with the help of Johnna Drucker, so we can already imagine proximity as a kind of interface. The nearness of this proximity, which can not be reduced to physical or cognitive closeness,<a href="#fn35" id="fnref35" class="footnoteRef"><sup>35</sup></a> is conceptualized with many other terms by Levinas, such as approach, contact, and responsibility. All of these terms connote a kind of engagement that is a process of being approached by a neighbor or a stranger that demands a response (response-ability) more than an intentionally willed choice to approach another and engage. This nearness in proximity demands participation before there is a choice. In a simple sense, the nearness of proximity describes as a process (approach) of encounter (contact) that demands participation (responsibility).

Typically, the kind of nearness just discussed, a nearness of approach, would involve a demand for an intimate knowledge of the other person to make the “relationship with” of proximity compelling. Yet, Levinas is exploring a nearness that is not dependent on such a knowledge, where approach as response precedes knowing. Here is where distance plays a role in proximity. There are two distances at work in the discussion of proximity in *Otherwise than Being.* The first distance is the distance of sight or knowledge or what Levinas phrases as the incomplete objective genitive construction, “consciousness of… .”<a href="#fn36" id="fnref36" class="footnoteRef"><sup>36</sup></a> This distance is simply the distance required for a subject to comprehend an object or for the eye to see an object. The nearness of proximity squeezes this distance by enacting a contact that precedes comprehension, an encounter that is blurry. While proximity in a Levinasian sense resists this distance of comprehension through a nearness of sociality not reducible to understanding, another kind of distance emerges.<a href="#fn37" id="fnref37" class="footnoteRef"><sup>37</sup></a> This second distance is another way of articulating the difference always at work in this encounter that is proximity.

Levinas calls this distance “a diachrony without a common present,” which suggests that even the nearness at work in proximity does not actually bring the two terms of this relationship or encounter or interface “together” in any reciprocal way in a shared appearance.<a href="#fn38" id="fnref38" class="footnoteRef"><sup>38</sup></a> This distance as diachrony or difference is not somehow an interruption of an original synchrony or sameness, to which a system is hoping to return. Rather, this distance as the ever expanding and insatiable demand by the other consistently troubles any attempts to master the needs of the other. Levinas writes, “The subject is the more responsible the more it answers for, as though the distance between it and the other increased in the measure that proximity was increased.”<a href="#fn39" id="fnref39" class="footnoteRef"><sup>39</sup></a> This sounds a great deal like Levinas’s reflections on the asymptote metaphor we saw above, where he writes, “The more I answer the more I am responsible; the more I approach the neighbor with which I am encharged the further away I am.”<a href="#fn40" id="fnref40" class="footnoteRef"><sup>40</sup></a> Here, the “further away” that indicates distance refers to the inexhaustibility of the responsibility operative in proximity. At no point, can one draw near enough through the approach of responsibility to master the needs of the other. Instead, as the nearness of proximity increases through response to the demand of the other as encounter, so does the inability to fulfill this demand and thus distance also increases. In short, this distance in proximity is resistance to mastery of the other by either exhausting the demand or returning to a originary synchrony of shared appearance. Proximate distance has no end or beginning, it is anarchic.

In this Levinasian reconstitution of human subjectivity, proximity is an expansion of both nearness and distance. Nearness is an involvement with the other that is characterized by a distance that resists mastery of the other. As the nearness of response-ability increases, so does the distance of one term’s ability to contain or define the other term in a deterministic and mechanistic manner.The interplay of this nearness and distance involved in the relationship that is proximity enacts both the proximity of contact and the ever ap-proximate response to the demand of the other, because it can never be mastered. This constant entanglement of nearness and distance brings together two other important terms used by Levinas in his explorations of *OTB*, disinterested non-indifference, which I have used as a synonym for proximity. Disinterested describes the difference of distance in dis-inter-esse, interrupting the need for a shared horizon of essence or sameness in order to participate in the relationship of proximity. Non-indifference communicates the engagement or nearness at work in the response-ability in the face of the demand of the other. So, disinterested non-indifference can be translated as distance nearness, both of which are attempts at articulating the operation of proximity as something otherwise than simple spatial contiguity.<a href="#fn41" id="fnref41" class="footnoteRef"><sup>41</sup></a>

## Interfacing Proximity

Can this notion of proximity in human-human interface articulated by Levinas be applied to human-machine interfaces in the context of use of bible? I think it can and Levinas offers at least two hints in this direction. First, as Sean Hand highlights so wonderfully in his analysis of Levinas’s evolving relationship with art, Levinas saw in Paul Celan’s poetry “a language of and for proximity.”<a href="#fn42" id="fnref42" class="footnoteRef"><sup>42</sup></a> Hand writes, “Levinas’s appreciation of Celan, in contrast \[with Heidegger on Hölderlin\], emphasizes the poverty, inadequacy and non-radiance of a language, a language that therefore signifies proximity rather than mastery, and a being for the other rather than a world in being.”<a href="#fn43" id="fnref43" class="footnoteRef"><sup>43</sup></a> Without delving into all of the details of a Levinasian philosophy of art or the ways in which poetry operates in language, we can see here in Hand’s comment and in Levinas’s own reflections on poetry that the nearness and distance of proximity are possible in poetry. Thus, if poetry can be a language of and for proximity, then interface has the potential to operate as a space of and for proximity.<a href="#fn44" id="fnref44" class="footnoteRef"><sup>44</sup></a>

More specifically related to our questions of bible as a proximate interface, Levinas describes his own relationship with bible as book using language that sounds a great deal like his discussions of proximity. In a set of interviews conducted in 197? on French radio with Philippe Nemo, transcribed in *Ethics and Infinity*, Levinas describes his relationship with bible in language that sounds a great deal like the operations of proximity. It was these very interviews that first stimulated my interest in the possibility of bible as a proximate interface. In the early discussions of the first interview, which is titled “Bible and Philosophy,” Levinas describes his view of bible as the book of books, saying, “It is that extraordinary presence of its characters, that ethical plenitude and its mysterious possibilities of exegesis which originally signified transcendence for me. And no less.”<a href="#fn45" id="fnref45" class="footnoteRef"><sup>45</sup></a> The “extraordinary presence” and “ethical plenitude” Levinas attributes to the bible can be read as synonyms for the nearness and distance of proximity, respectively.

The extraordinary presence of the biblical characters is not a celebration of the great cloud of witnesses in the biblical stories. Rather, these *characters* are the very letters of the text before they are assembled into words and phrases. These characters are *present* in ways that are beyond the ordinary, irreducible to the semiotic performance of their combinatorial effects.<a href="#fn46" id="fnref46" class="footnoteRef"><sup>46</sup></a> The bible demands a response from its users, a participation that opens to “mysterious possibilities of exegesis.” This nearness of bible suppresses the distance of reading as simple consumption or cognition and begs for an interface of book and user that exceeds comprehension. Ethical plenitude refers not to an abundantly recurring theme of ethics in the content of the biblical writings, but to the inexhaustible resistance to mastery enacted in encounter with this book. As we saw in the distance of proximity, even as a user approaches in response, bible can never be contained and thus will always overflow any possible fixed and stable readings, demanding ever more response.

Proximity emerges for Levinas as a reflection on human subjectivity and a particular and proximate interface of two humans. Through his reflections on poetry as language and bible as book, we see the operations of proximity at work in a different kind of interface, that between reader and text. Without any attempt or desire to suggest an equivalence between the mechanisms or gravity of human-human interface and user-bible interface, this proximity which entangles nearness and distance can give us a way to think about bible as interface in light of the anxieties around technological change we see throughout history.

## Affording Proximity

If the nearness in proximity is a kind of participatory encounter that demands a response and the distance of proximity inexhaustibly resists mastery of the system, what would it look like for an interface to afford the nearness and distance of proximity? As I said above, looking for affordances of proximity in interface may not enact all of the complex nuances of nearness and distance at work in the encounter with the other as articulated by Levinas. Yet, these ap-proximations of nearness and distance at work in the interfaces which are bible can condition users toward a disposition of proximity in human-human interface, just as bible first signaled transcendence for Levinas.<a href="#fn47" id="fnref47" class="footnoteRef"><sup>47</sup></a>

Interfaces that afford proximity exhibit high surface area, collaborative capacities, and anarchic tendencies. The combination of these characteristics in interface enacts both the response-ability of nearness and the resistance to mastery of distance in proximity. As we begin to consider the characteristics of interface, it is important to remember that both interface and affordance are relational concepts that exceed the material properties of the platform and user involved. So, for example, suggesting that twitter affords proximity because of its incredibly high surface area of 500 million tweets per day<a href="#fn48" id="fnref48" class="footnoteRef"><sup>48</sup></a> is less useful than finding proximity in the use of twitter to collaboratively share the location of family members and critically needed relief supplies during Hurricane Sandy on the eastern seaboard of the United States in the Fall of 2012. The platform of Twitter itself is not proximate, but Twitter can afford proximity in particular user interfaces.

Interfaces with high surface area have many possible points of contact between user and platform. The illustration I often use for high surface area is grinding coffee beans. The finer a coffee beans is ground, the more surface area that gets created for the water to contact and thus the water can draw more flavor from the bean. The expansive points of contact in high surface area interfaces afford the nearness of user interaction and participation as well as the distance of resisting mastery by making it impossible to touch all of the possible contact points. For example, watching a full length feature film straight through on Youtube is a fairly low surface area interface, since the user engages a continuous linear narrative that is taken in as a whole. On the other hand, searching YouTube for clips related to a recent election scandal can offer a high surface area interface through the many ways into the event offered by the search results.

The collaborative capacities of interfaces offer mechanisms for participation and contact in the process of constructing the space that is interface. Kindle reader on the iphone for example, affords several opportunities for the reader to participate in constructing the interface, such as choosing a font size or a background color for the page. Additionally, Kindle reader allows users to annotate and highlight as they use a book, which can create an entirely new navigation scheme through the material. We find a similar collaborative affordance in the marginalia so popular in medieval manuscripts. These Kindle annotations highlight another aspect of the collaborative capacities of interfaces, the communal process of use. Kindle reader allows users to share their annotations with others and users can enable a feature that will show popular highlights while reading through the book. This popular highlights feature is similar to checking out a book form the library and seeing the markings and highlights left by previous users. The Kindle reader example demonstrates the two layers of nearness operative in the collaborative capacities of proximate interfaces. First, there is a nearness of participation in constructing the material aspects of the interface and second, there is a nearness of community, using and making together not entirely on a user’s own terms.<a href="#fn49" id="fnref49" class="footnoteRef"><sup>49</sup></a>

The third characteristic of proximate interfaces that we will look for is a tendency toward anarchy. Levinas himself, speaks of proximity as anarchic, saying, “Proximity is thus anarchical, a relationship with a singularity without the mediation of any principle, any ideality.”<a href="#fn50" id="fnref50" class="footnoteRef"><sup>50</sup></a> It is the anarchy of proximity that first drew me to Levinas and it is the anarchy of proximity that offers bible an afterlife in our emerging media age with its proliferation of interfaces. Anarchy in the sense I use it here is something beyond disorder as another order and something significantly more complicated than the simple absence of a beginning or origin. Exploiting the *koine* semantic range of αρχη, which can mean beginning and reign, I hear the anarchic as that which is *without the reign of an original*.<a href="#fn51" id="fnref51" class="footnoteRef"><sup>51</sup></a> Just as the distance at work in proximity resists any mastery of the other, anarchy in interface resists the closure or consolidation of use to any mechanistic determinism governed by original author, original version, or final form. Enacting the distance of proximity, anarchy in interface constantly exceeds attempts by users to grasp and order the whole in a stable manner. The Talmudic page provides a beautiful example of anarchy in interface, even in the medium of print. The structure of the Talmudic page is very consistent, with Mishnah and Gemara down the center column and additional commentary around the page from there. Yet, the design of the page does not promote a reconstruction of any original meaning of the biblical text, the mishnah, or its commentary nor does it promote the reign of a single author or principle. Rather, the Talmudic page anarchically invites users to participate in the ongoing process of exploration and conversation.<a href="#fn52" id="fnref52" class="footnoteRef"><sup>52</sup></a> Articulating this anarchic sensibility of the Talmud, Jacob Neusner writes, “Every Talmudic tractate–there are thirty-seven of them in the Babylonian Talmud–begins on page 2; there are no page 1s because there is no beginning. Wherever you start your study, you will feel you have joined a conversation which began long before you came along.”<a href="#fn53" id="fnref53" class="footnoteRef"><sup>53</sup></a> Of course, every tractate does have a beginning, even if on page 2, and every user does start somewhere. The anarchy of the Talmudic page need not eradicate beginnings, or endings, in order to provide some proximate distance to resist the reign of these originary impulses. In interface, a tendency toward anarchy resists mastery and thus provides the distance of proximity.

With these three characteristics of proximate interface in mind, surface area, collaboration, and anarchy, we can now move toward looking at the affordances of this proximity in bible as interface throughout its many manifestations in media history. I will first trace the possibilities of proximity in bible as book through an ancient bible manuscript, a critical print edition of bible, and a kindle bible. Once we have seen the operations of nearness and distance in bible as book, I will explore the possible translations of proximity into bible as interface beyond book through manuscript digitization, XML encoding, and application programming interfaces (APIs). Amidst the common fears and anxieties emerging as new technologies threaten the dominance of the codex as our reading interface, attending to the affordance of proximity in bible as interface can help use of bible flourish beyond the book.

------------------------------------------------------------------------

1.  

    For the full context of this conversation and quote from Yencich, see “Codex All the Way Down” at http://aproximatebible.postach.io/post/codex-all-the-way-down.[↩](#fnref1)

2.  

    Sherry Turkle, *Reclaiming Conversation: The Power of Talk in a Digital Age* (New York: Penguin Books, 2015). For some samples of the attention this book has garnered, see https://storify.com/textpotential/turkle-face-to-face.[↩](#fnref2)

3.  

    Richard A Cohen, “Ethics and Cybernetics: Levinasian Reflections,” *Ethics and Information Technology* 2, no. 1 (June 1, 2000): 27–35.[↩](#fnref3)

4.  

    Sherry Turkle, *Life on the Screen: Identity in the Age of the Internet* (New York: Simon & Schuster Paperbacks, 2014).[↩](#fnref4)

5.  

    Cohen, “Ethics and Cybernetics,” 27 n. 2.[↩](#fnref5)

6.  

    Sherry Turkle, *Alone Together: Why We Expect More from Technology and Less from Each Other* (Cambridge, Mass.: Perseus Books, 2013). Turkle, *Reclaiming Conversation*.[↩](#fnref6)

7.  

    http://www.npr.org/2015/09/26/443480452/making-the-case-for-face-to-face-in-an-era-of-digital-conversation[↩](#fnref7)

8.  

    Nicholas Carr, *The Glass Cage - Automation and Us* (New York: WW NORTON & CO, 2015) and *Utopia is Creepy: And Other Provocations* (New York: W W NORTON & CO, 2017).[↩](#fnref8)

9.  

    Nicholas Carr, *The Shallows: What the Internet Is Doing to Our Brains* (New York: W. W. Norton & Co. Inc., 2010).[↩](#fnref9)

10. 

    Carr, *The Shallows*, Kindle Locations 1984-1986, writes, "when we go online, we enter an environment that promotes cursory reading, hurried and distracted thinking, and superficial learning. It’s possible to think deeply while surfing the Net, just as it’s possible to think shallowly while reading a book, but that’s not the type of thinking the technology encourages and rewards.[↩](#fnref10)

11. 

    Marshall McLuhan, Understanding Media: The Extensions of Man, (New York: McGraw-Hill, 1964), 7.[↩](#fnref11)

12. 

    McLuhan’s idea of the “global village,” made popular in his earlier book, *The Gutenberg Galaxy* (Toronto: University of Toronto Press, 1962) encapsulates the retribalization process I mention here.[↩](#fnref12)

13. 

    Clay Shirky, *Cognitive Surplus*: Creativity and Generosity in a Connected Age\* (New York: Penguin Press, 2010).[↩](#fnref13)

14. 

    Carr, *The Shallows*, Kindle locations 2812-2814, writes, “What that ancient Roman craftsman wove together when he created the first codex is unstitched. The quiet that was ‘part of the meaning’ of the codex is sacrificed as well. Surrounding every page or snippet of text on Google Book Search is a welter of links, tools, tabs, and ads, each eagerly angling for a share of the reader’s fragmented attention.”[↩](#fnref14)

15. 

    Carr, *The Shallows*, Kindle location 953-1016.[↩](#fnref15)

16. 

    *Phaedrus* 275b; Ong, *Orality and Literacy*, 78-81.[↩](#fnref16)

17. 

    https://senseandreference.wordpress.com/2010/10/27/reading-writing-and-what-plato-really-thought/ .[↩](#fnref17)

18. 

    *Phaedrus* 275d-e[↩](#fnref18)

19. 

    *Seventh Letter* 343; http://www.csuchico.edu/phil/sdobra\_mat/platopaper.html.[↩](#fnref19)

20. 

    The more well know essay by Heidegger, “The Question Concerning Technology” (QCT) is a revised version of the second lecture of this four part lecture series Heidegger gave in Bremen in 1949. Mark Blitz, “Understanding Heidegger on Technology,” The New Atlantis, Winter 2014, http://www.thenewatlantis.com/publications/understanding-heidegger-on-technology, provides a useful exploration of the relationship of QCT to the Bremen lectures and to the larger themes in Heidegger’s work.[↩](#fnref20)

21. 

    Martin Heidegger, *Bremen and Freiburg Lectures: Insight into That Which Is and Basic Principles of Thinking* (Bloomington: Indiana University Press, 2012), 3.[↩](#fnref21)

22. 

    Heidegger, *Bremen Lectures*, 3[↩](#fnref22)

23. 

    Heiegger, *Bremen Lectures*, 19, writes, “When we think the thing as thing, then we protect the essence of the thing in the region from where it essences. Thinging is the nearning of world. Nearing is the essence of nearness. Insofar as we protect the thing as thing, we dwell in nearness. The nearing of nearness is the authentic and sole dimension of the mirror-play of the world.”[↩](#fnref23)

24. 

    Heidegger, *Bremen Lectures*, 4.[↩](#fnref24)

25. 

    For a more exhaustive study of Heidegger’s thinking and writing on technology, Don Ihde, *Heidegger’s Technologies: Postphenomenological Perspectives* (New York: Fordham University Press, 2010), offers a thorough contextualization and critique of Heidegger’s views.[↩](#fnref25)

26. 

    Heidegger, *Bremen Lectures*, 23.[↩](#fnref26)

27. 

    Roger Silverstone, “Proper Distance: Toward an Ethics for Cyberspace,” in *Digital Media Revisited: Theoretical and Conceptual Innovation in Digital Domains*, ed. Gunnar Liestøl, Andrew Morrison, and Terje Rasmussen (Cambridge, Mass.: MIT Press, 2003), 469–90.[↩](#fnref27)

28. 

    Silverstone, “Proper Distance,” 470, 483.[↩](#fnref28)

29. 

    Silverstone, “Proper Distance,” 474-75.[↩](#fnref29)

30. 

    See Lucas Introna, “Phenomenological Approaches to Ethics and Information Technology”, *The Stanford Encyclopedia of Philosophy* (Summer 2011 Edition), Edward N. Zalta (ed.), URL = <a href="https://plato.stanford.edu/archives/sum2011/entries/ethics-it-phenomenology/" class="uri" class="uri">https://plato.stanford.edu/archives/sum2011/entries/ethics-it-phenomenology/</a>, for an introduction to these kinds of questions.[↩](#fnref30)

31. 

    As Richard Cohen, *Ethics and Cybernetics*, 28, notes, the most pivotal chapter of Levinas’s *Otherwise than Being*, which is titled “Substitution,” offers a fitting mention of proximity in relationship to terminology we often find in discussions of technology, such as “circulation of information” and "resolved into ‘images.’ After introducing the shortcomings associated with placing consciousness qua knowledge at the foundation of humanness, Levinas, *Otherwise Than Being*, 101, articulates an alternative, saying, “In starting with sensibility interpreted not as a knowing but as proximity, in seeking in language contact and sensibility, behind the circulation of information it becomes, we have endeavored to describe subjectivity as irreducible to consciousness and thematization. Proximity appears as the relationship with the other, who cannot be resolved into ”images" or be exposed in a theme. It is the relationship with what is not disproportionate to the arche in thematization, but incommensurable with it, with what does not derive its identity from the kerygmatic logos, and blocks all schematism."[↩](#fnref31)

32. 

    Levinas, *Otherwise Than Being*, 16-17, writes, “Everywhere proximity is conceived ontologically, that is, as a limit or complement to the accomplishment of the adventure of essence, which consists in persisting in essence and unfolding immanence, in remaining in an ego, in identity. Proximity remains a distance diminished, an exteriority conjured. The present study sets out to not conceive proximity in function of being.”[↩](#fnref32)

33. 

    Levinas, *OTB*, 94.[↩](#fnref33)

34. 

    Levinas, *OTB*, 17, writes, “It figures as what is near in a proximity that counts as sociality, which ‘excites’ by its pure and simple proximity.”[↩](#fnref34)

35. 

    Levinas, *OTB*, 48, writes, “An analysis that starts with proximity, irreducible to consciousness of…, and describable, if possible, as an inversion of its intentionality, will recognize this responsibility to be a substitution.”[↩](#fnref35)

36. 

    Levinas, *OTB*, 90.[↩](#fnref36)

37. 

    Levinas, *OTB*, 90, writes, “Proximity, suppression of the distance that consciousness of… involves, opens the distance of a diachrony without a common present, where difference is the past that cannot be caught up with, an unimaginable future, the non-representable status of the neighbor behind which I am late and obsessed by the neighbor. This difference is my non-indifference to the other. Proximity is a disturbance of the rememberable time.”[↩](#fnref37)

38. 

    Levinas, *OTB*, 90.[↩](#fnref38)

39. 

    *OTB*, 139-40. I would argue that Levinas unhelpfully uses proximity as a synonym for nearness in this passage, since proximity is the dual operation of increasing distance and nearness.[↩](#fnref39)

40. 

    Levinas, *OTB*, 94.[↩](#fnref40)

41. 

    Levinas, *OTB*, 139-141.[↩](#fnref41)

42. 

    Levinas, “Being and the Other: On Paul Celan,” 17, writes, “A language of and for proximity–more ancient than that of the ‘truth of Being’ (which it probably bears and supports), the first of languages–response preceding question, responsibility to the neighbor–, making possible through its ‘for the other’ the whole miracle of giving.”[↩](#fnref42)

43. 

    Hand, *Emmanuel Levinas*, 77.[↩](#fnref43)

44. 

    Levinas, *OTB*, 192 n. 10, makes another explicit claim for the relationship between poetry and proximity in his discussion of obsession, writing, “But is not the poetry of the world prior to the truth of things, and inseparable from what is proximity par excellence, that of a neighbor, or of the proximity of the neighbor par excellence.”[↩](#fnref44)

45. 

    Levinas, *Ethics and Infinity*, 23.[↩](#fnref45)

46. 

    In his reflections on revelation in the Jewish tradition, Levinas, *Beyond the Verse*, 132, suggests, "It is by going back to the Hebrew text from the translations, vulnerable as they may be, that the strange or mysterious ambiguity or polysemy authorized by the Hebrew syntax is revealed: words coexist rather than immediately being co-ordinated or subordinated with and to one another, contrary to what is predominant in the languages that are said to be developed or functional. This coexistence of words before and irreducible to their coordination is the extraordinary presence of the characters of the bible.[↩](#fnref46)

47. 

    See above, Levinas, *Ethics and Infinity*, 23.[↩](#fnref47)

48. 

    See http://www.internetlivestats.com/twitter-statistics/ for a running counter of tweets sent each day.[↩](#fnref48)

49. 

    Wikipedia offers another good example of collaborative capacities, where a user can participate in crafting an entry with a team of people from around the globe without any previous “knowledge” or who these partners are. Now, Wikipedia does not necessarily demand participation in the same way that the encounter with the other does in Levinasian subjectivity, because a user can simply take in the content of the page. Yet, again, the possibility of collaboration both in building the entry with strangers and sharing bits of it with others, as an affordance, has the potential to shape a disposition toward response-ability in human-human interface.[↩](#fnref49)

50. 

    Levinas, *OTB*, 101.[↩](#fnref50)

51. 

    Despite the semantic negation built into the word an-archy, I am uninterested in arguing for the absence of original. In my early attempts to articulate this anarchy in the realm of translation studies through a talk titled “From Murder to Anarchy” at the Nida School of Translation Studies 2014, I fear I had fallen into the trap of archaizing the anarchic by arguing for the eradication of the notion of original in the process of translation. The conversations with translators who have spent their lives caring for and working with both biblical and literary texts taught me that we needn’t eschew the presence, value, and operation of an original or source text in the process of translation in order to question said original’s governance over the validity or even methodology of a translation. We can always construct an original given a particular data set and time frame. Instead of eradicating any notion of original, I am asking us to consider a kind of reading, a mode of making, that operates *without the reign of an original*. In this vein, anarchy becomes one mechanism for the probabilistic production offered by interfaces that we discussed in chapter 1.[↩](#fnref51)

52. 

    Levinas, *Nine Talmudic Readings*, 5, points toward this anarchic sensibility of the Talmudic page, writing, “The pages of the Talmud, mischevious, laconic in their ironic or dry formulations, but in love with the possible, register an oral tradition and a teaching which came to be written down accidentally. It is important to bring them back to their life of dialog or polemic in which multiple, though not arbitrary, meanings arise and buzz in each saying. These Talmudic pages seek contradiction and expect of a reader freedom, invention and boldness.”[↩](#fnref52)

53. 

    Neusner, *Invitation to the Talmud: A Teaching Book*, 170. Joel Luri Grishaver, *Talmud with Training Wheels*, 13, points out that though Nuesner touches on a truth of Talmudic interface, tractates begin on page 2 also because page 1 was reserved materially for the title page.[↩](#fnref53)


